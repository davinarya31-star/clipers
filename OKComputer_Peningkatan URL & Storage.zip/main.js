// Global variables and state management
let currentUploads = [];
let processingQueue = [];
let animationController = null;

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Main initialization function
function initializeApp() {
    initializeAnimations();
    initializeUploadZone();
    initializeProcessingQueue();
    initializeScrollEffects();
    initializeP5Background();
    
    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Initialize text animations and effects
function initializeAnimations() {
    // Initialize Splitting.js for text animations
    Splitting();
    
    // Typed.js animation for hero text
    const typed = new Typed('#typed-text', {
        strings: [
            'Video Clipping',
            'Content Creation',
            'Scene Detection',
            'Auto Editing',
            'Smart Processing'
        ],
        typeSpeed: 80,
        backSpeed: 60,
        backDelay: 2000,
        loop: true,
        showCursor: true,
        cursorChar: '|'
    });
    
    // Animate hero elements on load
    anime.timeline({
        easing: 'easeOutExpo',
        duration: 1000
    })
    .add({
        targets: '[data-splitting] .char',
        opacity: [0, 1],
        translateY: [100, 0],
        delay: anime.stagger(50)
    })
    .add({
        targets: '.hero-bg p',
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 800
    }, '-=500')
    .add({
        targets: '.hero-bg .flex.flex-col',
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 800
    }, '-=400');
    
    // Animate feature cards on scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                anime({
                    targets: entry.target,
                    opacity: [0, 1],
                    translateY: [50, 0],
                    duration: 800,
                    easing: 'easeOutQuart'
                });
            }
        });
    });
    
    document.querySelectorAll('.card-hover').forEach(card => {
        observer.observe(card);
    });
}

// Initialize upload zone functionality
function initializeUploadZone() {
    const uploadZone = document.getElementById('file-upload-zone');
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'video/*';
    fileInput.multiple = true;
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);
    
    // Drag and drop events
    uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.classList.add('dragover');
    });
    
    uploadZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
    });
    
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        const files = Array.from(e.dataTransfer.files);
        handleFileUpload(files);
    });
    
    // Click to browse files
    uploadZone.addEventListener('click', () => {
        fileInput.click();
    });
    
    fileInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        handleFileUpload(files);
    });
}

// Switch between file upload and URL input modes
function switchUploadMode(mode) {
    const fileZone = document.getElementById('file-upload-zone');
    const urlZone = document.getElementById('url-input-zone');
    const fileBtn = document.getElementById('file-mode-btn');
    const urlBtn = document.getElementById('url-mode-btn');
    
    if (mode === 'file') {
        fileZone.classList.remove('hidden');
        urlZone.classList.add('hidden');
        fileBtn.classList.add('bg-blue-600', 'text-white');
        fileBtn.classList.remove('text-gray-300');
        urlBtn.classList.remove('bg-blue-600', 'text-white');
        urlBtn.classList.add('text-gray-300');
    } else {
        fileZone.classList.add('hidden');
        urlZone.classList.remove('hidden');
        urlBtn.classList.add('bg-blue-600', 'text-white');
        urlBtn.classList.remove('text-gray-300');
        fileBtn.classList.remove('bg-blue-600', 'text-white');
        fileBtn.classList.add('text-gray-300');
    }
}

// Process single URL
function processURL() {
    const urlInput = document.getElementById('url-input');
    const url = urlInput.value.trim();
    
    if (!url) {
        showNotification('URL Required', 'Please enter a video URL to process.', 'error');
        return;
    }
    
    if (!isValidURL(url)) {
        showNotification('Invalid URL', 'Please enter a valid video URL.', 'error');
        return;
    }
    
    processVideoURL(url);
    urlInput.value = '';
}

// Process multiple URLs
function processMultipleURLs() {
    const urlTextarea = document.getElementById('url-multiple-input');
    const urls = urlTextarea.value.split('\n').filter(url => url.trim() !== '');
    
    if (urls.length === 0) {
        showNotification('No URLs', 'Please enter at least one video URL.', 'error');
        return;
    }
    
    const validURLs = urls.filter(url => isValidURL(url.trim()));
    
    if (validURLs.length === 0) {
        showNotification('Invalid URLs', 'No valid URLs found. Please check your input.', 'error');
        return;
    }
    
    validURLs.forEach(url => processVideoURL(url.trim()));
    urlTextarea.value = '';
    
    showNotification('URLs Queued', `${validURLs.length} URLs have been added to processing queue.`, 'success');
}

// Validate URL format
function isValidURL(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

// Process video URL
function processVideoURL(url) {
    const urlData = {
        id: 'url-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9),
        url: url,
        platform: detectPlatform(url),
        name: extractVideoName(url),
        status: 'downloading',
        progress: 0,
        timestamp: new Date()
    };
    
    currentUploads.push(urlData);
    createURLProgress(urlData);
    simulateURLDownload(urlData);
    
    showNotification('URL Processing', `Processing ${urlData.platform} video...`, 'info');
}

// Detect video platform
function detectPlatform(url) {
    if (url.includes('youtube.com') || url.includes('youtu.be')) return 'YouTube';
    if (url.includes('vimeo.com')) return 'Vimeo';
    if (url.includes('tiktok.com')) return 'TikTok';
    if (url.includes('instagram.com')) return 'Instagram';
    return 'Direct Video';
}

// Extract video name from URL (simplified)
function extractVideoName(url) {
    try {
        const urlObj = new URL(url);
        return `Video from ${urlObj.hostname}`;
    } catch {
        return 'Video from URL';
    }
}

// Create URL progress UI
function createURLProgress(urlData) {
    const progressContainer = document.getElementById('upload-progress');
    progressContainer.classList.remove('hidden');
    
    const progressElement = document.createElement('div');
    progressElement.className = 'glass-effect rounded-lg p-4';
    progressElement.id = urlData.id;
    
    progressElement.innerHTML = `
        <div class="flex justify-between items-center mb-2">
            <span class="font-medium">Downloading from ${urlData.platform}</span>
            <span class="text-sm text-gray-400">0%</span>
        </div>
        <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="progress-bar rounded-full h-2" style="width: 0%"></div>
        </div>
        <p class="text-xs text-gray-400 mt-2">Connecting to ${urlData.platform}...</p>
    `;
    
    progressContainer.appendChild(progressElement);
}

// Simulate URL download (replace with real download logic)
function simulateURLDownload(urlData) {
    const progressElement = document.getElementById(urlData.id);
    const progressBar = progressElement.querySelector('.progress-bar');
    const percentageText = progressElement.querySelector('.text-gray-400');
    const statusText = progressElement.querySelector('p');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 8 + 2;
        if (progress > 100) progress = 100;
        
        progressBar.style.width = progress + '%';
        percentageText.textContent = Math.round(progress) + '%';
        
        if (progress < 30) {
            statusText.textContent = `Connecting to ${urlData.platform}...`;
        } else if (progress < 70) {
            statusText.textContent = `Downloading video...`;
        } else if (progress < 100) {
            statusText.textContent = `Processing video...`;
        } else {
            statusText.textContent = `Download complete! Starting AI analysis...`;
            clearInterval(interval);
            
            // Add to processing queue
            setTimeout(() => {
                addToProcessingQueue(urlData);
                progressElement.remove();
                
                // Hide progress container if no more uploads
                if (currentUploads.every(u => u.progress === 100)) {
                    document.getElementById('upload-progress').classList.add('hidden');
                }
            }, 2000);
        }
    }, 300);
}

// Handle file upload
function handleFileUpload(files) {
    files.forEach(file => {
        if (file.type.startsWith('video/')) {
            const uploadId = 'upload-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
            const uploadData = {
                id: uploadId,
                file: file,
                name: file.name,
                size: file.size,
                progress: 0,
                status: 'uploading',
                timestamp: new Date()
            };
            
            currentUploads.push(uploadData);
            createUploadProgress(uploadData);
            simulateUpload(uploadData);
        }
    });
}

// Create upload progress UI
function createUploadProgress(uploadData) {
    const progressContainer = document.getElementById('upload-progress');
    progressContainer.classList.remove('hidden');
    
    const progressElement = document.createElement('div');
    progressElement.className = 'glass-effect rounded-lg p-4';
    progressElement.id = uploadData.id;
    
    progressElement.innerHTML = `
        <div class="flex justify-between items-center mb-2">
            <span class="font-medium">Uploading ${uploadData.name}</span>
            <span class="text-sm text-gray-400">0%</span>
        </div>
        <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="progress-bar rounded-full h-2" style="width: 0%"></div>
        </div>
        <p class="text-xs text-gray-400 mt-2">Preparing upload...</p>
    `;
    
    progressContainer.appendChild(progressElement);
}

// Simulate upload progress (replace with real upload logic)
function simulateUpload(uploadData) {
    const progressElement = document.getElementById(uploadData.id);
    const progressBar = progressElement.querySelector('.progress-bar');
    const percentageText = progressElement.querySelector('.text-gray-400');
    const statusText = progressElement.querySelector('p');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15 + 5;
        if (progress > 100) progress = 100;
        
        progressBar.style.width = progress + '%';
        percentageText.textContent = Math.round(progress) + '%';
        
        if (progress < 30) {
            statusText.textContent = 'Uploading file...';
        } else if (progress < 70) {
            statusText.textContent = 'Processing video...';
        } else if (progress < 100) {
            statusText.textContent = 'Analyzing content...';
        } else {
            statusText.textContent = 'Upload complete! Starting AI analysis...';
            clearInterval(interval);
            
            // Add to processing queue
            setTimeout(() => {
                addToProcessingQueue(uploadData);
                progressElement.remove();
                
                // Hide progress container if no more uploads
                if (currentUploads.every(u => u.progress === 100)) {
                    document.getElementById('upload-progress').classList.add('hidden');
                }
            }, 2000);
        }
    }, 200);
}

// Add file to processing queue
function addToProcessingQueue(uploadData) {
    const processingItem = {
        id: 'process-' + Date.now(),
        name: uploadData.name,
        status: 'analyzing',
        progress: 0,
        scenes: Math.floor(Math.random() * 20) + 5,
        clips: Math.floor(Math.random() * 10) + 3,
        timestamp: new Date()
    };
    
    processingQueue.push(processingItem);
    updateProcessingQueue();
    simulateProcessing(processingItem);
}

// Initialize processing queue UI
function initializeProcessingQueue() {
    // Queue is already initialized in HTML
}

// Update processing queue display
function updateProcessingQueue() {
    // This would update the processing queue section
    // For demo purposes, we'll just log the updates
    console.log('Processing queue updated:', processingQueue);
}

// Simulate AI processing
function simulateProcessing(processingItem) {
    const phases = [
        { name: 'Analyzing video content', duration: 3000 },
        { name: 'Detecting scene changes', duration: 2500 },
        { name: 'Identifying key moments', duration: 2000 },
        { name: 'Generating clips', duration: 4000 },
        { name: 'Optimizing for platforms', duration: 1500 },
        { name: 'Finalizing output', duration: 1000 }
    ];
    
    let currentPhase = 0;
    
    function processNextPhase() {
        if (currentPhase < phases.length) {
            const phase = phases[currentPhase];
            
            // Update UI with current phase
            console.log(`Processing: ${phase.name}`);
            
            setTimeout(() => {
                currentPhase++;
                processingItem.progress = Math.round((currentPhase / phases.length) * 100);
                
                if (currentPhase < phases.length) {
                    processNextPhase();
                } else {
                    processingItem.status = 'complete';
                    processingItem.progress = 100;
                    console.log('Processing complete!');
                    
                    // Show completion notification
                    showNotification('Processing Complete!', `${processingItem.name} has been successfully processed into ${processingItem.clips} clips.`);
                }
            }, phase.duration);
        }
    }
    
    processNextPhase();
}

// Initialize scroll effects
function initializeScrollEffects() {
    // Parallax effect for hero section
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const heroSection = document.querySelector('.hero-bg');
        
        if (heroSection) {
            const rate = scrolled * -0.5;
            heroSection.style.transform = `translateY(${rate}px)`;
        }
        
        // Update navigation blur effect
        const nav = document.querySelector('nav');
        if (scrolled > 50) {
            nav.style.background = 'rgba(10, 10, 10, 0.95)';
        } else {
            nav.style.background = 'rgba(10, 10, 10, 0.8)';
        }
    });
}

// Initialize P5.js background animation
function initializeP5Background() {
    new p5((p) => {
        let particles = [];
        let numParticles = 50;
        
        p.setup = function() {
            const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
            canvas.parent('p5-canvas');
            
            // Create particles
            for (let i = 0; i < numParticles; i++) {
                particles.push({
                    x: p.random(p.width),
                    y: p.random(p.height),
                    vx: p.random(-0.5, 0.5),
                    vy: p.random(-0.5, 0.5),
                    size: p.random(2, 6),
                    opacity: p.random(0.1, 0.3)
                });
            }
        };
        
        p.draw = function() {
            p.clear();
            
            // Update and draw particles
            particles.forEach(particle => {
                // Update position
                particle.x += particle.vx;
                particle.y += particle.vy;
                
                // Wrap around edges
                if (particle.x < 0) particle.x = p.width;
                if (particle.x > p.width) particle.x = 0;
                if (particle.y < 0) particle.y = p.height;
                if (particle.y > p.height) particle.y = 0;
                
                // Draw particle
                p.fill(0, 102, 255, particle.opacity * 255);
                p.noStroke();
                p.ellipse(particle.x, particle.y, particle.size);
                
                // Draw connections
                particles.forEach(other => {
                    const distance = p.dist(particle.x, particle.y, other.x, other.y);
                    if (distance < 100) {
                        p.stroke(0, 102, 255, (1 - distance / 100) * particle.opacity * 50);
                        p.strokeWeight(1);
                        p.line(particle.x, particle.y, other.x, other.y);
                    }
                });
            });
        };
        
        p.windowResized = function() {
            p.resizeCanvas(p.windowWidth, p.windowHeight);
        };
    });
}

// Utility functions
function scrollToUpload() {
    const uploadSection = document.getElementById('upload-section');
    uploadSection.scrollIntoView({ behavior: 'smooth' });
}

function showDemo() {
    showNotification('Demo Coming Soon!', 'We\'re preparing an interactive demo for you.');
}

function showNotification(title, message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 glass-effect rounded-lg p-4 max-w-sm transform translate-x-full transition-transform duration-300`;
    
    const iconColor = type === 'success' ? 'text-emerald-400' : type === 'error' ? 'text-red-400' : 'text-blue-400';
    
    notification.innerHTML = `
        <div class="flex items-start space-x-3">
            <div class="flex-shrink-0">
                <svg class="w-6 h-6 ${iconColor}" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <div class="flex-1">
                <h4 class="font-semibold text-white">${title}</h4>
                <p class="text-sm text-gray-300 mt-1">${message}</p>
            </div>
            <button onclick="this.parentElement.parentElement.remove()" class="text-gray-400 hover:text-white">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + U for upload
    if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
        e.preventDefault();
        scrollToUpload();
    }
    
    // Escape to close modals/notifications
    if (e.key === 'Escape') {
        const notifications = document.querySelectorAll('.fixed.top-20.right-4');
        notifications.forEach(notification => notification.remove());
    }
});

// Handle page visibility changes for performance
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Pause animations when page is not visible
        if (animationController) {
            animationController.pause();
        }
    } else {
        // Resume animations when page becomes visible
        if (animationController) {
            animationController.play();
        }
    }
});

// Export functions for use in other pages
window.ClipMasterAI = {
    showNotification,
    initializeAnimations,
    initializeUploadZone,
    processingQueue,
    currentUploads
};